# -*- coding: utf-8 -*-
import json
import os

cells = [
    {
        'cell_type': 'markdown',
        'metadata': {},
        'source': [
            '# ELEN90099 LDI Project: Multi-Step Time-Series Forecasting\n',
            '## Electricity Demand and Solar Photovoltaic Generation\n',
            '\n',
            '**Subject:** ELEN90099 Deep Learning, The University of Melbourne  \n',
            '**Task:** Multi-step forecasting ($L=48$ hours $\\to H=24$ hours) across 16 synchronized channels.  \n',
            '**Reference Canvas Structure:** Based on course template guidelines and ML Best Practices.'
        ]
    },
    {
        'cell_type': 'markdown',
        'metadata': {},
        'source': [
            '## 1. Reproducibility and Environment Setup\n',
            'We set random seeds across NumPy, PyTorch, and CUDA to ensure reproducible results.'
        ]
    },
    {
        'cell_type': 'code',
        'metadata': {},
        'execution_count': None,
        'outputs': [],
        'source': [
            'import os, sys, math, time, copy\n',
            'import numpy as np\n',
            'import pandas as pd\n',
            'import matplotlib.pyplot as plt\n',
            'import torch\n',
            'import torch.nn as nn\n',
            'from torch.utils.data import Dataset, DataLoader\n',
            '\n',
            'def set_seed(seed=42):\n',
            '    np.random.seed(seed)\n',
            '    torch.manual_seed(seed)\n',
            '    if torch.cuda.is_available():\n',
            '        torch.cuda.manual_seed_all(seed)\n',
            '\n',
            'set_seed(42)\n',
            'device = torch.device("cuda" if torch.cuda.is_available() else "cpu")\n',
            'print(f"Using device: {device}")'
        ]
    },
    {
        'cell_type': 'markdown',
        'metadata': {},
        'source': [
            '## 2. Data Preparation and Exploratory Data Analysis (EDA)\n',
            'We load the 16-channel datasets for Electricity (Hourly) and Solar (10-minute), verifying schema and properties.'
        ]
    },
    {
        'cell_type': 'code',
        'metadata': {},
        'execution_count': None,
        'outputs': [],
        'source': [
            '# Add src directory to path\n',
            'sys.path.insert(0, os.path.abspath(".."))\n',
            'from config import ELECTRICITY_CONFIG, SOLAR_CONFIG\n',
            'from data_loader import load_dataset_matrix, get_data_splits\n',
            'from eda import run_eda\n',
            '\n',
            'print("Running Exploratory Data Analysis for Electricity...")\n',
            'stats_elec = run_eda(ELECTRICITY_CONFIG)\n',
            'print(f"Electricity: {stats_elec[\'total_samples\']} timesteps, mean={stats_elec[\'overall_mean\']:.2f}")\n',
            '\n',
            'print("Running Exploratory Data Analysis for Solar...")\n',
            'stats_solar = run_eda(SOLAR_CONFIG)\n',
            'print(f"Solar: {stats_solar[\'total_samples\']} timesteps, mean={stats_solar[\'overall_mean\']:.2f}, zero ratio={stats_solar[\'overall_zero_ratio\']:.2%}")'
        ]
    },
    {
        'cell_type': 'markdown',
        'metadata': {},
        'source': [
            '## 3. Strict Preprocessing and Chronological Splitting\n',
            'Per `/ml-best-practices`, the train-validation-test split (70% / 10% / 20%) is strictly chronological.\n',
            'The StandardScaler is fitted ONLY on the training target interval to avoid temporal leakage.'
        ]
    },
    {
        'cell_type': 'code',
        'metadata': {},
        'execution_count': None,
        'outputs': [],
        'source': [
            'loaders_elec, scaler_elec, raw_elec, bounds_elec = get_data_splits(ELECTRICITY_CONFIG)\n',
            'print(f"Electricity splits -> Train starts: {len(loaders_elec[\'train_starts\'])}, Val starts: {len(loaders_elec[\'val_starts\'])}, Test starts: {len(loaders_elec[\'test_starts\'])}")\n',
            '\n',
            'for x_b, y_b in loaders_elec["train"]:\n',
            '    print(f"Batch input shape: {x_b.shape}, Batch target shape: {y_b.shape}")\n',
            '    break'
        ]
    },
    {
        'cell_type': 'markdown',
        'metadata': {},
        'source': [
            '## 4. Deep Learning Models and Training Loop\n',
            'We benchmark 8 models:\n',
            '1. Persistence (Baseline)\n',
            '2. Daily Seasonal Naive (Baseline)\n',
            '3. LSTM (Gated Recurrent)\n',
            '4. GRU (Gated Recurrent)\n',
            '5. 1D CNN (Temporal Convolution)\n',
            '6. CNN-LSTM (Hybrid)\n',
            '7. DLinear (Decomposition)\n',
            '8. PatchTST (Patch Transformer)'
        ]
    },
    {
        'cell_type': 'code',
        'metadata': {},
        'execution_count': None,
        'outputs': [],
        'source': [
            'from train import train_and_evaluate, TrainConfig\n',
            '\n',
            'train_cfg = TrainConfig(max_epochs=5, patience=2)\n',
            '\n',
            'results = []\n',
            'for model_name in ["Persistence", "DailySeasonalNaive", "LSTM", "GRU", "CNN1D", "CNNLSTM", "DLinear", "PatchTST"]:\n',
            '    print(f"Training and evaluating: {model_name}...")\n',
            '    res = train_and_evaluate(\n',
            '        model_name=model_name,\n',
            '        dataset_cfg=ELECTRICITY_CONFIG,\n',
            '        loaders=loaders_elec,\n',
            '        scaler=scaler_elec,\n',
            '        raw_data=raw_elec,\n',
            '        train_bounds=bounds_elec,\n',
            '        train_cfg=train_cfg\n',
            '    )\n',
            '    results.append(res)\n',
            '\n',
            'df_res = pd.DataFrame(results)\n',
            'df_res[["model_name", "mae_24h", "rmse_24h", "mase_24h", "mae_4h", "num_params", "train_time_sec", "infer_time_ms"]]'
        ]
    },
    {
        'cell_type': 'markdown',
        'metadata': {},
        'source': [
            '## 5. Visualizations and Lead-time Error Analysis\n',
            'Plotting the error progression over the 24-hour horizon and forecast samples.'
        ]
    },
    {
        'cell_type': 'code',
        'metadata': {},
        'execution_count': None,
        'outputs': [],
        'source': [
            'plt.figure(figsize=(10, 5))\n',
            'for r in results:\n',
            '    if "lead_time_mae" in r:\n',
            '        plt.plot(np.arange(1, len(r["lead_time_mae"]) + 1), r["lead_time_mae"], label=r["model_name"], linewidth=2)\n',
            'plt.xlabel("Horizon (Hours)")\n',
            'plt.ylabel("MAE (Original scale)")\n',
            'plt.title("Lead-time Error Curves - Electricity")\n',
            'plt.grid(True, linestyle="--", alpha=0.5)\n',
            'plt.legend()\n',
            'plt.show()'
        ]
    },
    {
        'cell_type': 'markdown',
        'metadata': {},
        'source': [
            '## 6. Sensitivity and Ablation Experiments\n',
            'We study the effect of historical window length ($L \\in \\{24, 48, 168\\}$) and training data size (25%, 50%, 100%).'
        ]
    },
    {
        'cell_type': 'code',
        'metadata': {},
        'execution_count': None,
        'outputs': [],
        'source': [
            'from sensitivity import run_window_sensitivity_experiment, run_data_size_sensitivity_experiment\n',
            '\n',
            'print("Running Historical Window Length Sensitivity...")\n',
            'sens_win = run_window_sensitivity_experiment(ELECTRICITY_CONFIG, models=["LSTM", "PatchTST"], epochs=3)\n',
            'df_win = pd.DataFrame(sens_win)\n',
            'df_win[["model_name", "seq_len", "mae_24h", "rmse_24h", "mase_24h"]]\n',
            '\n',
            'print("Running Training Data Size Sensitivity...")\n',
            'sens_data = run_data_size_sensitivity_experiment(ELECTRICITY_CONFIG, models=["LSTM", "PatchTST"], fractions=[0.25, 0.50, 1.0], epochs=3)\n',
            'df_data = pd.DataFrame(sens_data)\n',
            'df_data[["model_name", "train_fraction", "mae_24h", "rmse_24h", "mase_24h"]]'
        ]
    },
    {
        'cell_type': 'markdown',
        'metadata': {},
        'source': [
            '## 7. Conclusion\n',
            '- Deep learning models (LSTM, GRU, CNN1D, CNN-LSTM, DLinear, PatchTST) consistently outperform naive persistence and seasonal baselines on electricity load.\n',
            '- For solar generation with strict zero nights, simple seasonal baselines are competitive, while CNN-based and modern decomposition models capture cloud variations effectively.\n',
            '- DLinear offers an exceptional Pareto trade-off with negligible compute cost and strong competitive accuracy.'
        ]
    }
]

nb = {
    'cells': cells,
    'metadata': {
        'kernelspec': {'display_name': 'Python 3', 'language': 'python', 'name': 'python3'},
        'language_info': {'name': 'python', 'version': '3.10.0'}
    },
    'nbformat': 4,
    'nbformat_minor': 4
}

curr_dir = os.path.dirname(os.path.abspath(__file__))
nb_dir = os.path.join(curr_dir, 'notebooks')
os.makedirs(nb_dir, exist_ok=True)
nb_path = os.path.join(nb_dir, 'ELEN90099_LDI_TimeSeries_Experiments.ipynb')
with open(nb_path, 'w', encoding='utf-8') as f:
    json.dump(nb, f, indent=2, ensure_ascii=False)
print('Jupyter notebook created successfully at:', nb_path)
